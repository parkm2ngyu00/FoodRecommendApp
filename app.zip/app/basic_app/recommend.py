import json
import pandas as pd
from surprise import Reader, Dataset, KNNBasic, KNNWithMeans,SVD
from surprise.model_selection import train_test_split
import surprise
import tqdm

def newRating(newUserDf):
  newRating = pd.DataFrame(columns=['user', 'food', 'rating'])
  user = []
  food = []
  rating = []
  for j in range(newUserDf.shape[0]):
    name = newUserDf.index[j]
    for i in range(newUserDf.shape[1]):
      if newUserDf.loc[name][i] != 0:
        user.append(name)
        food.append(newUserDf.columns[i])
        rating.append(newUserDf.loc[name][i])
  newRating['user'] = user
  newRating['food'] = food
  newRating['rating'] = rating
  return newRating

def newUser(newdict,data_ratings):
  newUser = list(newdict.keys())
  foodName = data_ratings.columns.values.tolist()
  newUserDf = pd.DataFrame(index=newUser, columns=foodName)
  newUserDf.fillna(0.0, inplace=True)
  for j, name in enumerate(newUser):
    for i in range(len(newdict[name])):
      if newdict[name][i]['name'] in list(newUserDf.columns):
        newUserDf.__getitem__(newdict[name][i]['name']).__setitem__(name, newdict[name][i]['y'])
  return newUserDf

def makeRecommendationList(newUserDf,newRating,dr,df,cbcf_df,tfidf_df):
  dr = dr.append(newUserDf)
  df = df.append(newRating,sort=False,ignore_index=True)
  cbcf_df = cbcf_df.append(newRating,sort=False,ignore_index=True)
  tfidf_df = tfidf_df.append(newRating,sort=False,ignore_index=True)
  reader = Reader(rating_scale=(df['rating'].min(), df['rating'].max())) # 평점이 0.01 ~ 1.0점 사이
  data = Dataset.load_from_df(df[['user', 'food', 'rating']], reader=reader)
  reader2 = Reader(rating_scale=(cbcf_df['rating'].min(), cbcf_df['rating'].max())) # 평점이 0.01 ~ 1.0점 사이
  data2 = Dataset.load_from_df(cbcf_df[['user', 'ingre', 'rating']], reader=reader)
  reader3 = Reader(rating_scale=(tfidf_df['rating'].min(), tfidf_df['rating'].max())) # 평점이 0.01 ~ 1.0점 사이
  data3 = Dataset.load_from_df(tfidf_df[['user', 'food', 'rating']], reader=reader)
  trainset = data.build_full_trainset()
  trainset2 = data2.build_full_trainset()
  trainset3 = data3.build_full_trainset()
  #cos = SVD()
  #cos = cos.fit(trainset)
  #cf - SVD 10초 , CF 1분 20초 , KNN 1분 (어떤 로컬에서 돌리느냐에 따라 시간차가 큼)
  sim_options = {'name': 'cosine'}
  cos = KNNBasic(sim_options=sim_options)
  cos = cos.fit(trainset)
  #knn
  knn = KNNWithMeans(random_state=0)
#  knn = SVD()
#  knn = KNNBasic(sim_options=sim_options)
  knn = knn.fit(trainset)
  #cbcf + knn
  knn2 = KNNWithMeans(random_state=0)
  #knn2 = SVD()
#  knn2 = KNNBasic(sim_options=sim_options)
  knn2 = knn2.fit(trainset2)

  #tfidf + knn
  knn3 = KNNWithMeans(random_state=0) #KNN
#  knn3 = KNNBasic(sim_options=sim_options) #CF
#  knn3 = SVD() #SVD
  knn3 = knn3.fit(trainset3)


  return dr,cos,knn,knn2,knn3

def recommend_food_by_5algo(userId, dr, cos, knn, knn2, knn3): 
  result = pd.DataFrame()
  no_rating_list = get_no_rating_food(userId, dr)
  #cf
  result['cos'] = recommend_food(cos, userId, no_rating_list)
  #knn
  result['knn'] = recommend_food(knn, userId, no_rating_list)
  #cbcf + knn
  result['cbcf+knn'] = recommend_food(knn2, userId, no_rating_list)
  #tfidf + knn
  result['tf-idf+knn'] = recommend_food(knn3, userId, no_rating_list)
  print(type(json.dumps(result.T.to_dict())))
  return result
 # return resultjson


def recommend_food(algo, userId, no_rating_foods, top_n=20):  # https://techblog-history-younghunjo1.tistory.com/117
  # 알고리즘 객체의 predict()를 이용해 특정 userId의 평점이 없는 음식들에 대해 평점 예측
  predictions = [algo.predict(str(userId), str(foodId)) for foodId in no_rating_foods]

  # predictions는 Prediction()으로 하나의 객체로 되어있기 때문에 예측평점(est값)을 기준으로 정렬해야함
  # est값을 반환하는 함수부터 정의. 이것을 이용해 리스트를 정렬하는 sort()인자의 key값에 넣어주자!
  def sortkey_est(pred):
    return pred.est

  # sortkey_est함수로 리스트를 정렬하는 sort함수의 key인자에 넣어주자
  # 리스트 sort는 디폴트값이 inplace=True인 것처럼 정렬되어 나온다. reverse=True가 내림차순
  predictions.sort(key=sortkey_est, reverse=True)
  # 상위 n개의 예측값들만 할당
  top_predictions = predictions[:top_n]
  # top_predictions에서 food id, rating 뽑아내기
  top_food_ids = [pred.iid for pred in top_predictions]
  # zip함수를 사용해서 각 자료구조(여기선 리스트)의 똑같은 위치에있는 값들을 mapping
  # zip함수는 참고로 여러개의 문자열의 똑같은 위치들끼리 mapping도 가능!
  top_food_preds = [(ids) for ids in top_food_ids]
  return top_food_preds

def get_no_rating_food(userId, data_rating): # 평점 없는 음식 리스트 반환
    foodlist = list(data_rating.columns)
    df_userId = data_rating.where(data_rating > 0).loc[userId]
    ratings = list(df_userId.dropna().index)
    for food in ratings:
      foodlist.remove(food)
    return foodlist

def parseCsv(data_ratings,df_ratings,df_ingre_ratings,df_tfidf_ratings):
  data_ratings.rename(columns={'Unnamed: 0': ''}, inplace=True)
  data_ratings.set_index('', inplace=True)

  df_ratings.rename(columns={'Unnamed: 0': ''}, inplace=True)
  df_ratings.set_index('', inplace=True)

  df_ingre_ratings.rename(columns={'Unnamed: 0': ''}, inplace=True)
  df_ingre_ratings.set_index('', inplace=True)

  df_tfidf_ratings.rename(columns={'Unnamed: 0': ''}, inplace=True)
  df_tfidf_ratings.set_index('', inplace=True)

  return data_ratings,df_ratings,df_ingre_ratings,df_tfidf_ratings