{% load static %}

<html>

<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<title>음식 개인화 추천 알고리즘 연구</title>
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<script type="text/javascript" src="https://code.jquery.com/jquery-1.12.4.js" ></script>
<script src="https://kit.fontawesome.com/81c3a813c6.js" crossorigin="anonymous"></script>
<!--<link rel="stylesheet" href="{% static 'css/style.css' %}">
<link rel="stylesheet" href="{% static 'css/surveyStyle.css' %}">
<script src="{% get_static_prefix %}json/recommend/{{userInfo}}.json" type="text/javascript"></script>-->
<style>
@import url(https://spoqa.github.io/spoqa-han-sans/css/SpoqaHanSansNeo.css);

/* ------------- 수정 부분 시작 ------------- */

.resultBox {
height: 550px;
}

.page-indicator {
    position:fixed;
    width: 100px;
    top:30%;
    right:0px;
    transform:translateY(-50%);
    padding: 15px 10px;
    transition:transform 0.3s;
    background-color: var(--grey);
    color: var(--green);
    font-size: 9pt;
    border-radius: 10px 0px 0px 10px;
    text-align: center;
    z-index: 9;
}

.page-indicator > ul > li.active {
    font-weight: bold;
    font-size: 11pt;
}

html[data-current-page-index="0"] .page-indicator {
    transform:translateY(0);
}

* { font-family: 'Spoqa Han Sans Neo', 'sans-serif'; }

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

:root { 
--green: #235748;
--black: #222222;
--white: #fff;
--grey: #ebebeb;
--lightgreen: #65897f;
}

html,body {
padding: 0;
margin: 0;
color: var(--green);
background-color: var(--white);
overflow: auto;
-webkit-font-smoothing: antialiased;
}

img {
max-width: 100%;
border: 0px;
}

a:link    {color:inherit;text-decoration:none;}
a:visited {color:inherit;text-decoration:none;}
a:active  {color:inherit;text-decoration:none;}
a:hover   {color:inherit;text-decoration:none;}

::-webkit-scrollbar {
    width: 5px;
    height: 5px;
    background: var(--yellow);
}

::-webkit-scrollbar-thumb {
    width: 5px;
    background: var(--green);
}

@keyframes opacity {
0% {opacity:0;}
100% {opacity:1;}
}

@keyframes opacity2 {
0% {opacity:0;}
30% {opacity:0;}
100% {opacity:1;}
}

@keyframes blink {
0% {position:relative;left:0px;}
10% {position:relative;left:7px;}
20% {position:relative;left:-7px;}
30% {position:relative;left:3px;}
40% {position:relative;left:-3px;}
70% {position:relative;left:0px;}
}

.container {
display: flex; 
flex-wrap: wrap; 
align-items: center; 
justify-content: center;
text-align: center;
animation: opacity 0.7s ease-in-out;
-webkit-animation: opacity 0.7s ease-in-out;
}

.contents h1 {
margin-bottom: 40px;
letter-spacing: -2px;
}

.contents {
max-width: 90%;
}

/* p style & button style */

.p1 {
font-size: 10pt;
font-weight: 400;
letter-spacing: -0.5px;
line-height: 170%;
}

.p2 {
width: auto;
font-size: 9pt;
border: 1.5px solid var(--green);
padding: 3px 10px;
border-radius: 7px;
letter-spacing: -0.3px;
}

.bt1 {
border: 0px;
display: block;
margin: auto;
margin-top: 50px;
background-color: var(--green);
color: var(--white);
font-size: 12pt;
font-weight: 500;
letter-spacing: -1px;
border-radius: 50px;
padding: 13px 40px;
cursor: pointer;
transition: 0.3s;
animation: blink 2s infinite;
-webkit-animation: blink 2s infinite;
}

.bt1:hover {
transform:scale(1.1);
}

.bt1 i {
position: relative;
left: 20px;
top: -1px;
font-size: 10pt;
}

@media screen and (max-width: 830px) {

}

.container {
padding: 70px 0px;
max-width: 340px;
margin:auto;
}

.contents h2 {
margin-bottom: 40px;
letter-spacing: -2px;
}




/* survey.html*/

#surveyBox {
padding-top: 50px;
animation: opacity2 1s ease-in-out;
-webkit-animation: opacity2 1s ease-in-out;
}

.surveyItem {
text-align: left;
width: 300px;
padding: 30px 20px;
border-radius: 20px;
margin: 20px auto;
box-shadow: 0px 0px 10px 0px var(--grey);
font-size: 11pt;
font-weight: 500;
letter-spacing: -0.5px;
}

.surveyItem .num {
font-size: 5px;
border-radius: 50%;
margin-right: 10px;
position: relative;
top: -2px;
}

ul {list-style: none;}
ul li {display: inline-block;}

.surveyRadio {
float: right;
}

.surveyRadio input[type=radio]{
visibility: hidden;
position: relative;
z-index: 2;
margin: 0px 10px;
}

.surveyRadio label {
padding: 15px;
cursor: pointer;
display: inline-block;
margin-left: -30px;
top: -5px;
position: relative;
z-index: 5;
//background-color:rgba(0,0,0,0.5);
}

ul li .check{
  display: block;
  position: relative;
  top: -33px;
  left: 5px;
  border-radius: 100%;
  height: 27px;
  width: 27px;
z-index: 1;
transition: 0.3s all ease;
}

ul li .check i{
opacity: 0;
position: absolute;
color: white;
padding: 7.5px;
font-size: 12px;
transition: 0.3s all ease;
}

.color1 {background-color:#a6a6a6;}
.color2 {background-color:var(--lightgreen);}
.color3 {background-color:var(--green);}

ul li:hover .check {
transform: scale(0.8);
}

input[type=radio]:checked ~ .check i{
opacity: 1;
}

.bt1 {
margin: 70px auto 80px;
}

.p_circle {
border-radius:50%;
display: inline-block;
padding: 5px;
position: relative;
top: 0px;
margin: 0px 5px;
}




/* result.html*/

.resultBox {
margin-bottom: 30px;
border-top: 1px solid var(--grey);
padding: 20px 0px;
}

.resultBox h3 {
letter-spacing: -1px;
margin: 20px auto 30px;
font-weight: 500;
}

.resultBox li {
width: 50%;
letter-spacing: -0.5px;
}

input[type=checkbox]{
display:none;
}

.resultBox label {
display: inline-block;
width: 94%;
padding: 8px 0px;
margin: 5px 3%;
box-shadow: 0px 0px 6px 0px var(--grey);
border: 1px solid var(--white);
border-radius: 50px;
font-size: 9pt;
transition: 0.3s all ease;
cursor:pointer;
}

.resultBox li label:hover{
border: 1px solid var(--green);
}

.resultBox li input[type=checkbox]:checked ~ label {
border: 1px solid var(--green);
background-color:var(--green);
color: white;
}
 

/* ------------- 수정 부분 시작 ------------- */
.surveyItem select {
width: 85px;
margin: 0px 0px 0px 7px;
border: 1px solid var(--grey);
border-radius: 6px;
}
/* ------------- 수정 부분 끝 ------------- */


<!------------------ 수정 영역 -------------------->
html {
overflow-y: hidden;
}

#popup {
width: 100%;
height: 100%;
padding: 1px;
position: fixed;
z-index: 9999;
left: 0;
right: 0;
top: 0;
bottom: 0;
margin: auto;
display: none;
background-color: rgba(255, 255, 255, 0.85);
text-align: center;
z-index: 999;
}

#popup img {
width: 40px;
margin-bottom: 20px;
}

#popup .p_contents {
text-align: center;
height: 150px;
position: fixed;
z-index: 9999;
left: 0;
right: 0;
top: 0;
bottom: 0;
margin: auto;
font-size: 11pt;
letter-spacing: -0.5px;
}
/* ------------- 수정 부분 끝 ------------- */


.spoon {
width: 40px;
margin-bottom: 20px;
}

.copy {
font-size: 7pt;
letter-spacing: 0px;
font-weight: bold;
position: fixed;
left: 0;
right: 0;
margin: auto;
bottom: 20px;
text-align: center;
color: var(--green);
z-index: 99999;
}
</style>
</head>

<body oncontextmenu="return false" onselectstart="return false" ondragstart="return false">

<div class="container">
<div class="contents">
<img src=https://imgur.com/QdKeshR.png class=spoon>
<h2>음식 개인화 추천 알고리즘<br>성능 평가</h2>
<p class="p1">인공지능이 설문자님의 기호를 기반으로<br>추천하는 음식 20가지입니다.<br><br>알고리즘은 총 5개입니다.<br>알고리즘별로 마음에 드는 음식을 모두 선택해 주세요.<br><br></p>

<form action="{% url 'outro' %}" method="POST">{% csrf_token %}

<input type="hidden" name='userInfo' id='userInfo' value={{userInfo}}>


<div id="surveyBox">

<div id="resultBox0" class="resultBox">
<h3>알고리즘1</h3>
</div>

<div id="resultBox1" class="resultBox">
<h3>알고리즘2</h3>
</div>

<div id="resultBox2" class="resultBox">
<h3>알고리즘3</h3>
</div>

<div id="resultBox3" class="resultBox">
<h3>알고리즘4</h3>
</div>

<div id="resultBox4" class="resultBox">
<h3>알고리즘5</h3>
</div>

<input type="submit" name="submit" class="bt1" value='평가 제출하기'>
</form>

</div>
</div>

<div class="copy">(C) 2022 DKU & FARMKIT. All rights reserved.</div>

<script>
        var storage = JSON.parse("{{jsonFile|escapejs}}");
        for(i in storage.data) {
          let ul = document.createElement('ul');
          for(let j = 0; j < 20; j++) {
            let li = document.createElement('li');
            li.innerHTML = '<input type="checkbox" id="algo'+i+'food'+j+'" name="algo'+i+'[]" value="' + storage.data[i][j] + '"><label for="algo'+i+'food'+j+'">' + storage.data[i][j] + '</label>';
            ul.appendChild(li);
          }
          document.getElementById("resultBox"+i).appendChild(ul);
        }
</script>

</body>
</html>