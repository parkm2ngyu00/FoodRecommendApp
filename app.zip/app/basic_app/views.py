from datetime import time

from django.shortcuts import render
import json
from collections import OrderedDict
import pandas as pd
from basic_app import recommend
#global count
#count = 0

def index(request):
    return render(request, 'index.html')

def survey(request):
    return render(request, 'survey.html')

def result(request):
    gender = request.POST['gender']
    age = request.POST['age']
    userId = request.POST['userId']
    name = gender + age + "_" + userId

    data_ratings = pd.read_csv('basic_app/csv//userfood.csv')
    df_ratings = pd.read_csv('basic_app/csv/userFoodRating123.csv')
    df_ingre_ratings = pd.read_csv('basic_app/csv/userRatingCBCF(1-2-3).csv')
    df_tfidf_ratings = pd.read_csv('basic_app/csv/tdidfuserFoodRating.csv')
    dr,df,cbcf_df,tfidf_df = recommend.parseCsv(data_ratings,df_ratings,df_ingre_ratings,df_tfidf_ratings)
    #global count
    #name = request.POST['gender']+request.POST['age']+"_"+str(count)
    #name = "data"
    #count = count +1
    newdict = {}
    newdict[name] = [{"name": request.POST['food0'], "y": float(request.POST['rating0'])},
         {"name": request.POST['food1'], "y": float(request.POST['rating1'])},
         {"name": request.POST['food2'], "y": float(request.POST['rating2'])},
         {"name": request.POST['food3'], "y": float(request.POST['rating3'])},
         {"name": request.POST['food4'], "y": float(request.POST['rating4'])},
         {"name": request.POST['food5'], "y": float(request.POST['rating5'])},
         {"name": request.POST['food6'], "y": float(request.POST['rating6'])},
         {"name": request.POST['food7'], "y": float(request.POST['rating7'])},
         {"name": request.POST['food8'], "y": float(request.POST['rating8'])},
         {"name": request.POST['food9'], "y": float(request.POST['rating9'])},
         {"name": request.POST['food10'], "y": float(request.POST['rating10'])},
         {"name": request.POST['food11'], "y": float(request.POST['rating11'])},
         {"name": request.POST['food12'], "y": float(request.POST['rating12'])},
         {"name": request.POST['food13'], "y": float(request.POST['rating13'])},
         {"name": request.POST['food14'], "y": float(request.POST['rating14'])},
         {"name": request.POST['food15'], "y": float(request.POST['rating15'])},
         {"name": request.POST['food16'], "y": float(request.POST['rating16'])},
         {"name": request.POST['food17'], "y": float(request.POST['rating17'])},
         {"name": request.POST['food18'], "y": float(request.POST['rating18'])},
         {"name": request.POST['food19'], "y": float(request.POST['rating19'])}]

    newUserDf = recommend.newUser(newdict, dr)

    newRating = recommend.newRating(newUserDf)

    dr, cos, knn, knn2, knn3 = recommend.makeRecommendationList(newUserDf, newRating, dr, df, cbcf_df, tfidf_df)

    result = recommend.recommend_food_by_5algo(name, dr, cos, knn, knn2, knn3)
    resultjson = result.T.values.tolist()

    resultjson2 = {"data": resultjson}

    path = "./basic_app/static/json/recommend/"+name+".json"
    with open(path, "w+", encoding='utf-8') as file:
        json.dump(resultjson2, file, ensure_ascii=False)

    return render(request, 'result.php', {'userInfo': name, 'jsonFile': json.dumps(resultjson2)})

def outro(request):
    name = request.POST['userInfo']
    print(name)

    newDict = {}

    for i in range(4): #5개 알고리즘에 대해 (현재 팜킷 없이 4)
        algo = "algo"+str(i)+"[]"
        checkList = request.POST.getlist(algo)
        newDict[algo] = checkList

    newData = {"data": newDict}
    #print(newData)

    path = "./basic_app/static/json/result/"+name+".json"
    with open(path, "w+", encoding='utf-8') as file:
        json.dump(newData, file, ensure_ascii=False)

    return render(request, 'outro.html')
